<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
<head>
  <?php $this->load->view('main/css_view'); ?>
  <title><?= $page_title ?></title>
</head>
<body class="bg-gradient-dark bg-image h-100">
  <div class="loader-container bg-glass" style="display:none"><span class="loader"></span></div>

  <div class="container">
    <div class="row justify-content-center">
