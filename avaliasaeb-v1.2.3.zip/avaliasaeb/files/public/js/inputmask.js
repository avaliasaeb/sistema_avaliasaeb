(function($) {

  //input mask
  $('[mask-telefone]').inputmask("(99) 9 9999-9999");

})(jQuery);
